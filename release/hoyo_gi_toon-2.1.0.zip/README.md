# Hoyo-GI-Toon

面向原神 PMX 角色的材质渲染插件，以接近游戏内的 Toon 表现、接入 MMD 流程为目标。

直接使用场景中已有的 MMD 模型，也可导入新的 PMX。当前进度、实施清单和验收状态统一见 [开发记录](design/DEVELOPMENT.md)。

## 使用流程

1. 启用 MMD Tools，打开 3D 视图侧栏的 Hoyo-GI-Toon。
2. 选中已有模型的网格、骨架或 MMD 根对象；也可在 **模型** 中选择。新模型使用 **导入 PMX**。
3. 点击 **应用材质**，直接调整阴影位置、描边及选中材质的颜色。
4. 按需点击 **默认光**，或选择现有太阳光。旋转灯光可调整 Toon 光向。
5. 使用当前场景相机，或主动点击 **相机对齐当前视角**；没有相机时会创建。按需启用 **看向相机**。
6. 点击 **渲染**，结果显示在 Blender 原生渲染窗口；分辨率、保存和动画渲染使用 Blender 原生功能。

材质、打光、相机和渲染入口直接铺开。已有模型接入读取工程中的材质与贴图，不要求重新选择 PMX、不重复导入或修骨。导入新 PMX 时自动修复骨骼，并在场景没有相机时创建一个；构图由用户设置。

应用材质同步 Eevee／Standard 的 Toon 渲染条件，使视口和原生渲染使用同一材质链路。原生渲染保留完整场景和用户输出设置。表情与动作继续使用 MMD Tools／Blender；背景和地面由用户自己的场景管理。

**材质参数**提供当前材质的颜色、阴影颜色和有描边时的描边颜色；全局阴影位置、描边粗细也集中于此。**恢复原材质**还原导入时的网格和材质，独立创建的相机与默认光保留。

操作与限制见 [使用说明](docs/workflow.md)，材质语义见 [PMX 渲染](docs/pmx-rendering.md)，来源见 [模块接口](docs/upstream-baseline.md)。

## 交付与保留记录

源码与正式包见 [GitHub](https://github.com/muchuanhehua/Hoyo-GI-Toon) 和 [Releases](https://github.com/muchuanhehua/Hoyo-GI-Toon/releases)。

远程更新源：`https://raw.githubusercontent.com/muchuanhehua/Hoyo-GI-Toon/main/release/index.json`

FBX、附件分类、旧表情面板、背景和地面已退出当前实现，旧代码与工程使用方式见 [1.0.1 保留记录](design/legacy-v1.0.1.md)。模型、游戏贴图与私人验证工程不进入安装包。
