# 模块来源与接口

目标是原生 Blender 中的原神 PMX 材质渲染和 MMD 流程。参考实现按模块选用，保留原节点与来源；资产读取场景中模型的实际引用，也支持可选 PMX 导入。

| 模块 | 接口与责任 | 来源 |
|---|---|---|
| PMX 导入 | importers.import_character、mmd_importer.import_model；导入、骨骼修复及前后记录 | MMD Tools 公开 Operator |
| 场景模型 | scene_models；已有 MMD 模型识别、当前选择与材质恢复记录，不重复导入或修骨 | Hoyo-GI-Toon |
| 资产保护 | asset_tracking；导入引用、派生网格、恢复及事务 | Hoyo-GI-Toon |
| 材质适配 | pmx_materials.Catalog / build；Toon、Sphere、Alpha、边线 | Gacha Setup 的 PMX 适配原则 |
| 原生着色 | shaders.ShaderLibrary；Body、Hair、Face、光向与描边节点 | Festivity、michael-gh1 的原生模板 |
| 脸部资源 | face_catalog、face_assets、face_sdf；内置共用场／遮罩选择及明确引用自动匹配，分离数据通道与眼部遮罩 | 原生 Festivity；资源与语义参考 Gacha Setup／晨星；数据图归属 HoYoverse，见 assets/faces.json |
| 头部与光向 | head_binding、lighting；主脸权重校验、原生头部参照、单主光源代表方向 | 结合 MAVR 的头部置信检查与光向组织方式 |
| 参数 | material_controls；逐材质颜色与全局阴影描边 | Hoyo-GI-Toon |
| 默认光 | lighting.default_light；主动调用，复用自有灯 | Hoyo-GI-Toon |
| 视线 | gaze；可移除眼骨约束及实时跟随 | Hoyo-GI-Toon；MMD 骨名语义参考晨星 |
| 工程与渲染 | project_io、rendering；资源记录、当前场景相机和 Blender 原生渲染，图片保存使用原生功能 | Hoyo-GI-Toon / Blender |
| 编排与面板 | workflow、panels；六个独立可折叠面板，材质实时预览，无自定义输出区 | Hoyo-GI-Toon |

来源资源版本与摘要见 `assets/upstream.json`，版权与许可见 `NOTICE`。旧版完整功能及参考范围保留于 v1.0.1，当前不接入 FBX、附件分类、表情编辑、背景或地面模块。
